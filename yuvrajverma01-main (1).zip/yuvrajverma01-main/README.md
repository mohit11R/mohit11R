<h2> Hey there! I'm Yuvraj. ✌️</h2>

<a href="https://www.linkedin.com/in/yuvrajverma01/">
  <img align="left" alt="Yuvraj's LinkdeIN" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>
<a href="https://www.instagram.com/yuvrajverma01/">
  <img align="left" alt="Yuvraj's Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />
</a>
<a href="https://www.youtube.com/watch?v=3jEZnZD6phQ&t=0s">
  <img align="left" alt="Yuvraj's YouTube" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/youtube.svg" />
</a>
<a href="https://twitter.com/01_barfi">
  <img align="left" alt="Yuvraj's Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />
</a>
<br>
<h3> 👨🏻‍💻 About Me </h3>

- 🔭 I’m currently learning Cyber Security
- 🎓 Currently pursuing Computer Science Engineering (Sophomore) 
- 👨‍💻 Python developer and front-end web developer.
- 🔭 Exploring Competetive Programming
- 🌱 Enthusiast in Cyber Security and Machine Learning
- 🏃‍♂️ About to document my journey on [YouTube](https://www.youtube.com/watch?v=3jEZnZD6phQ&t=0s)
- ⚡ Life shrinks and expands on the proportion of your willingness to take risks and try new things 

<h3>🛠 Tech Stack</h3>

- 💻 Python | C | C++ | Java | JavaScript | PyPy3
- 🔧 PyCharm | Visual Studio code | Atom | Git | Notion
- 💽 Adobe Xd | Illustrator | Photoshop | Premier Pro | Lightroom

<br>

<a href="https://github.com/yuvrajverma01">
 <img align="center" src="https://github-readme-stats.vercel.app/api?username=yuvrajverma01&show_icons=true&theme=light&line_height=27" alt="Yuvraj's github stats"/>
</a>

